#!/usr/bin/env python3
"""Emit STM32G0_BUTTONBOARD_PROG.ioc.

Hand-authoring the .ioc keeps CubeMX and the checked-in sources telling the
same story: open the project, hit Generate Code, and the pin configuration
that comes out is the one board_pins.h already describes.
"""

# (cube pin name, signal, mode-or-None, gpio label, extra key/values)
PINS = [
    ("PA0",  "S_TIM2_CH1", None, "ENC_A", {}),
    ("PA1",  "S_TIM2_CH2", None, "ENC_B", {}),
    ("PA2",  "GPIO_Input", None, "ENC_BUT", {}),
    ("PA5",  "GPIO_Output", None, "LED_OUT", {"GPIO_PuPd": "GPIO_NOPULL"}),
    ("PA8",  "GPIO_Input", None, "Button_3V3_4", {}),
    ("PA9",  "GPIO_Input", None, "Button_3V3_5", {}),
    ("PA10", "GPIO_Input", None, "Button_3V3_int_4", {}),
    ("PA11", "GPIO_Input", None, "SW_1_3V3", {}),
    ("PA12", "GPIO_Input", None, "SW_2_3V3", {}),
    ("PA13", "SYS_SWDIO", None, "TMS", {}),
    ("PA14-BOOT0", "SYS_SWCLK", None, "TCK", {}),
    ("PA15", "GPIO_Input", None, "SW_3_3V3", {}),
    ("PB0",  "GPIO_Input", None, "ROT_SW_1", {}),
    ("PB1",  "GPIO_Input", None, "ROT_SW_2", {}),
    ("PB2",  "GPIO_Input", None, "ROT_SW_3", {}),
    ("PB3",  "GPIO_Output", None, "BUTTON_INT_3_uC", {}),
    ("PB4",  "GPIO_Output", None, "BUTTON_INT_4_uC", {}),
    ("PB6",  "I2C1_SCL", "I2C", "I2C_SCL", {}),
    ("PB7",  "I2C1_SDA", "I2C", "I2C_SDA", {}),
    ("PB8",  "FDCAN1_RX", "FDCAN_Activate", "CAN_RX", {"GPIO_PuPd": "GPIO_PULLUP"}),
    ("PB9",  "FDCAN1_TX", "FDCAN_Activate", "CAN_TX", {}),
    ("PB10", "GPIO_Input", None, "ROT_SW_4", {}),
    ("PB11", "GPIO_Input", None, "ROT_SW_5", {}),
    ("PB12", "GPIO_Input", None, "ROT_SW_6", {}),
    ("PB13", "GPIO_Input", None, "Button_3V3_1", {}),
    ("PB14", "GPIO_Input", None, "Button_3V3_2", {}),
    ("PB15", "GPIO_Input", None, "Button_3V3_3", {}),
    ("PC0",  "GPIO_Output", None, "BUFF_SEL_1", {}),
    ("PC1",  "GPIO_Output", None, "BUFF_SEL_2", {}),
    ("PC5",  "GPIO_Input", None, "ROT_SW_0", {}),
    ("PC6",  "GPIO_Input", None, "Button_3V3_6", {}),
    ("PC7",  "GPIO_Input", None, "Button_3V3_int_1", {}),
    ("PC8",  "GPIO_Input", None, "SW_4_3V3", {}),
    ("PC9",  "GPIO_Output", None, "BUTTON_1_uC", {}),
    ("PC13", "GPIO_Input", None, "BlueButton", {}),
    ("PD0",  "GPIO_Output", None, "BUTTON_2_uC", {}),
    ("PD1",  "GPIO_Output", None, "BUTTON_3_uC", {}),
    ("PD2",  "GPIO_Output", None, "BUTTON_4_uC", {}),
    ("PD3",  "GPIO_Output", None, "BUTTON_5_uC", {}),
    ("PD4",  "GPIO_Output", None, "BUTTON_6_uC", {}),
    ("PD5",  "GPIO_Output", None, "BUTTON_INT_1_uC", {}),
    ("PD6",  "GPIO_Output", None, "BUTTON_INT_2_uC", {}),
    ("PD8",  "GPIO_Input", None, "Button_3V3_int_2", {}),
    ("PD9",  "GPIO_Input", None, "Button_3V3_int_3", {}),
    ("PF0-OSC_IN\\ (PF0)",  "RCC_OSC_IN",  "HSE-External-Oscillator", None, {}),
    ("PF1-OSC_OUT\\ (PF1)", "RCC_OSC_OUT", "HSE-External-Oscillator", None, {}),
]

lines = ["#MicroXplorer Configuration settings - do not modify"]
lines += [
    "CAD.formats=",
    "CAD.pinconfig=",
    "CAD.provider=",
    "FDCAN1.CalculateBaudRateNominal=500000",
    "FDCAN1.CalculateTimeBitNominal=2000",
    "FDCAN1.CalculateTimeQuantumNominal=133.33333333333334",
    "FDCAN1.IPParameters=CalculateTimeQuantumNominal,CalculateTimeBitNominal,"
    "CalculateBaudRateNominal,NominalPrescaler,NominalTimeSeg1,NominalTimeSeg2,"
    "NominalSyncJumpWidth,AutoRetransmission,StdFiltersNbr",
    "FDCAN1.AutoRetransmission=DISABLE",
    "FDCAN1.NominalPrescaler=8",
    "FDCAN1.NominalSyncJumpWidth=1",
    "FDCAN1.NominalTimeSeg1=10",
    "FDCAN1.NominalTimeSeg2=4",
    "FDCAN1.StdFiltersNbr=1",
    "File.Version=6",
    "GPIO.groupedBy=Group By Peripherals",
    "I2C1.IPParameters=Timing",
    "I2C1.Timing=0x00B01E60",
    "KeepUserPlacement=false",
    "Mcu.CPN=STM32G0B1RET6",
    "Mcu.Family=STM32G0",
    "Mcu.IP0=FDCAN1",
    "Mcu.IP1=I2C1",
    "Mcu.IP2=NVIC",
    "Mcu.IP3=RCC",
    "Mcu.IP4=SYS",
    "Mcu.IP5=TIM2",
    "Mcu.IPNb=6",
    "Mcu.Name=STM32G0B1R(B-C-E)Tx",
    "Mcu.Package=LQFP64",
]

for i, (pin, *_rest) in enumerate(PINS):
    lines.append(f"Mcu.Pin{i}={pin}")
lines.append("Mcu.Pin%d=VP_SYS_VS_Systick" % len(PINS))
lines.append("Mcu.Pin%d=VP_TIM2_VS_ControllerModeEncoder" % (len(PINS) + 1))
lines.append("Mcu.Pin%d=VP_TIM2_VS_ClockSourceINT" % (len(PINS) + 2))
lines.append("Mcu.PinsNb=%d" % (len(PINS) + 3))
lines += [
    "Mcu.ThirdPartyNb=0",
    "Mcu.UserConstants=",
    "Mcu.UserName=STM32G0B1RETx",
    "MxCube.Version=6.12.0",
    "MxDb.Version=DB.6.0.120",
    "NVIC.ForceEnableDMAVector=true",
    "NVIC.HardFault_IRQn=true\\:0\\:0\\:false\\:false\\:true\\:false\\:false\\:false",
    "NVIC.NonMaskableInt_IRQn=true\\:0\\:0\\:false\\:false\\:true\\:false\\:false\\:false",
    "NVIC.PendSV_IRQn=true\\:0\\:0\\:false\\:false\\:true\\:false\\:false\\:false",
    "NVIC.SVC_IRQn=true\\:0\\:0\\:false\\:false\\:true\\:false\\:false\\:false",
    "NVIC.SysTick_IRQn=true\\:3\\:0\\:false\\:false\\:true\\:false\\:true\\:false",
    "NVIC.TIM16_FDCAN_IT0_IRQn=true\\:0\\:0\\:false\\:false\\:true\\:true\\:true\\:true",
]

for pin, signal, mode, label, extra in PINS:
    if label:
        lines.append(f"{pin}.GPIO_Label={label}")
    if extra:
        lines.append(f"{pin}.GPIOParameters=" + ",".join(sorted(extra)))
        for k, v in sorted(extra.items()):
            lines.append(f"{pin}.{k}={v}")
    if mode:
        lines.append(f"{pin}.Mode={mode}")
    lines.append(f"{pin}.Locked=true")
    lines.append(f"{pin}.Signal={signal}")

lines += [
    "ProjectManager.AskForMigrate=true",
    "ProjectManager.BackupPrevious=false",
    "ProjectManager.CompilerOptimize=6",
    "ProjectManager.ComputerToolchain=false",
    "ProjectManager.CoupleFile=false",
    "ProjectManager.CustomerFirmwarePackage=",
    "ProjectManager.DefaultFWLocation=true",
    "ProjectManager.DeletePrevious=true",
    "ProjectManager.DeviceId=STM32G0B1RETx",
    "ProjectManager.FirmwarePackage=STM32Cube FW_G0 V1.6.2",
    "ProjectManager.FreePins=false",
    "ProjectManager.HalAssertFull=false",
    "ProjectManager.HeapSize=0x200",
    "ProjectManager.KeepUserCode=true",
    "ProjectManager.LastFirmware=true",
    "ProjectManager.LibraryCopy=1",
    "ProjectManager.MainLocation=Core/Src",
    "ProjectManager.NoMain=false",
    "ProjectManager.PreviousToolchain=",
    "ProjectManager.ProjectBuild=false",
    "ProjectManager.ProjectFileName=STM32G0_BUTTONBOARD_PROG.ioc",
    "ProjectManager.ProjectName=STM32G0_BUTTONBOARD_PROG",
    "ProjectManager.ProjectStructure=",
    "ProjectManager.RegisterCallBack=",
    "ProjectManager.StackSize=0x400",
    "ProjectManager.TargetToolchain=STM32CubeIDE",
    "ProjectManager.ToolChainLocation=",
    "ProjectManager.UAScriptAfterPath=",
    "ProjectManager.UAScriptBeforePath=",
    "ProjectManager.UnderRoot=true",
    "ProjectManager.functionlistsort=1-SystemClock_Config-RCC-false-HAL-false,"
    "2-MX_GPIO_Init-GPIO-false-HAL-true,"
    "3-MX_FDCAN1_Init-FDCAN1-false-HAL-true,"
    "4-MX_I2C1_Init-I2C1-false-HAL-true,"
    "5-MX_TIM2_Init-TIM2-false-HAL-true",
    "RCC.AHBFreq_Value=60000000",
    "RCC.APBFreq_Value=60000000",
    "RCC.APBTimFreq_Value=60000000",
    "RCC.CortexFreq_Value=60000000",
    "RCC.FCLKCortexFreq_Value=60000000",
    "RCC.FDCANFreq_Value=60000000",
    "RCC.FamilyName=M",
    "RCC.HCLKFreq_Value=60000000",
    "RCC.HSE_VALUE=8000000",
    "RCC.I2C1Freq_Value=60000000",
    "RCC.IPParameters=AHBFreq_Value,APBFreq_Value,APBTimFreq_Value,"
    "CortexFreq_Value,FCLKCortexFreq_Value,FDCANFreq_Value,FamilyName,"
    "HCLKFreq_Value,HSE_VALUE,I2C1Freq_Value,PLLM,PLLN,PLLPoutputFreq_Value,"
    "PLLQoutputFreq_Value,PLLRCLKFreq_Value,PLLSourceVirtual,"
    "PWRFreq_Value,SYSCLKFreq_VALUE,SYSCLKSource,TIM1Freq_Value,"
    "VCOInputFreq_Value,VCOOutputFreq_Value",
    "RCC.PLLM=RCC_PLLM_DIV1",
    "RCC.PLLN=15",
    "RCC.PLLPoutputFreq_Value=60000000",
    "RCC.PLLQoutputFreq_Value=15000000",
    "RCC.PLLRCLKFreq_Value=60000000",
    "RCC.PLLSourceVirtual=RCC_PLLSOURCE_HSE",
    "RCC.PWRFreq_Value=60000000",
    "RCC.SYSCLKFreq_VALUE=60000000",
    "RCC.SYSCLKSource=RCC_SYSCLKSOURCE_PLLCLK",
    "RCC.TIM1Freq_Value=60000000",
    "RCC.VCOInputFreq_Value=8000000",
    "RCC.VCOOutputFreq_Value=120000000",
    "TIM2.EncoderMode=TIM_ENCODERMODE_TI12",
    "TIM2.IC1Filter=15",
    "TIM2.IC2Filter=15",
    "TIM2.IPParameters=Period,EncoderMode,IC1Filter,IC2Filter",
    "TIM2.Period=0xFFFF",
    "VP_SYS_VS_Systick.Mode=SysTick",
    "VP_SYS_VS_Systick.Signal=SYS_VS_Systick",
    "VP_TIM2_VS_ClockSourceINT.Mode=Internal",
    "VP_TIM2_VS_ClockSourceINT.Signal=TIM2_VS_ClockSourceINT",
    "VP_TIM2_VS_ControllerModeEncoder.Mode=Encoder_Mode",
    "VP_TIM2_VS_ControllerModeEncoder.Signal=TIM2_VS_ControllerModeEncoder",
    "board=custom",
    "isbadioc=false",
]

with open("/tmp/bb/app/STM32G0_BUTTONBOARD_PROG.ioc", "w", newline="\n") as f:
    f.write("\n".join(lines) + "\n")
print("wrote .ioc with", len(PINS), "pins,", len(lines), "lines")
