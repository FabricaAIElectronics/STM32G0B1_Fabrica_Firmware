#!/usr/bin/env python3
"""Register the ButtonBoard with the V&V gate.

Without this the gate silently covers only four boards — the new one would
build fine and never be checked against its own DBC or the address plan,
which is the failure mode the gate exists to prevent.
"""
import io
import os
import re
import sys

errors = []


def read(p):
    with io.open(p, encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with io.open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write(s)


def sub_once(text, old, new, what):
    if old not in text:
        errors.append("anchor not found: %s" % what)
        return text
    return text.replace(old, new, 1)


# ---------------------------------------------------------------------------
# vv/boards.py — the registry every stage reads.
# ---------------------------------------------------------------------------
p = "vv/boards.py"
t = read(p)
entry = '''    Board(
        id="buttonboard",
        name="ButtonBoard",
        mcu="STM32G0B1RET6",
        app_dir=f"{_APP_G0}/STM32G0_BUTTONBOARD_PROG",
        app_eclipse="STM32G0_BUTTONBOARD_PROG",
        boot_dir=f"{_BOOT_G0}/G0B1_ButtonBoard_Boot",
        boot_eclipse="G0B1_ButtonBoard_Boot",
        dbc=f"{_APP_G0}/STM32G0_BUTTONBOARD_PROG/ButtonBoard.dbc",
        headers=(f"{_APP_G0}/STM32G0_BUTTONBOARD_PROG/Core/Inc/can_operation.h",),
        blt_rx=0x780,
        blt_tx=0x781,
        bitrate=500000,
        extended=False,
        boot_reserved_bytes=RESERVE_G0B1,
        app_origin=0x08003000,
        flash_total_bytes=FLASH_512K,
        address_plan_exempt=False,
        in_bus_doc=True,
    ),
    # The knob predates'''
t = sub_once(t, "    # The knob predates", entry, "boards.py knob comment anchor")
write(p, t)

# ---------------------------------------------------------------------------
# vv/checks/conformance.py — the address plan.
# ---------------------------------------------------------------------------
p = "vv/checks/conformance.py"
t = read(p)
t = sub_once(t,
             '    "leddriver": (0x160, 0x17F),\n}',
             '    "leddriver": (0x160, 0x17F),\n'
             '    # Outside the CiA-301 gap because that gap is full; see\n'
             '    # Docs/CAN_Bus.md section 2.\n'
             '    "buttonboard": (0x780, 0x7BF),\n}',
             "conformance SUB_BLOCKS")
write(p, t)

# ---------------------------------------------------------------------------
# vv/unit/layouts.h — the asserted byte layouts.
# ---------------------------------------------------------------------------
p = "vv/unit/layouts.h"
t = read(p)
rows = '''
    /* ButtonBoard - little endian uint16, matching the knob's Knob.dbc
     * convention rather than PowerStage/LEDDriver's big endian. */
    {"buttonboard", 0x780, "Bootloader_RX",    2, "little"},
    {"buttonboard", 0x790, "Cmd_Led",          2, "little"},
    {"buttonboard", 0x791, "Cmd_Buffer",       1, "little"},
    {"buttonboard", 0x792, "Cmd_Encoder",      3, "little"},
    {"buttonboard", 0x793, "Cmd_EEPROM",       1, "little"},
    {"buttonboard", 0x7A0, "Knob_State",       8, "little"},
    {"buttonboard", 0x7A1, "Buttons",          2, "little"},
    {"buttonboard", 0x7A2, "Led_State",        3, "little"},
    {"buttonboard", 0x7A3, "Dev_Status",       2, "little"},
    {"buttonboard", 0x7A4, "EEPROM_Data",      8, "little"},

    /* Knob - no DBC, recorded for completeness only */'''
t = sub_once(t, "\n    /* Knob - no DBC, recorded for completeness only */",
             rows, "layouts.h knob comment")
write(p, t)

# ---------------------------------------------------------------------------
# vv/unit/test_can_layout.c — the JSON exporter iterates a hard-coded list.
# ---------------------------------------------------------------------------
p = "vv/unit/test_can_layout.c"
t = read(p)
t = sub_once(t,
             '    const char *boards[] = {"kincodrive", "powerstage", "leddriver", "knob"};\n'
             '    for (unsigned b = 0; b < 4; b++) {',
             '    const char *boards[] = {"kincodrive", "powerstage", "leddriver",\n'
             '                            "buttonboard", "knob"};\n'
             '    const unsigned nboards = sizeof(boards) / sizeof(boards[0]);\n'
             '    for (unsigned b = 0; b < nboards; b++) {',
             "test_can_layout boards array")
t = sub_once(t,
             'fprintf(fh, "\\n    ]%s\\n", b == 3 ? "" : ",");',
             'fprintf(fh, "\\n    ]%s\\n", b == nboards - 1 ? "" : ",");',
             "test_can_layout trailing comma")
write(p, t)

if errors:
    sys.stderr.write("VV PATCH ERRORS:\n  " + "\n  ".join(errors) + "\n")
    sys.exit(1)
print("patch_vv.py: all anchors matched")
