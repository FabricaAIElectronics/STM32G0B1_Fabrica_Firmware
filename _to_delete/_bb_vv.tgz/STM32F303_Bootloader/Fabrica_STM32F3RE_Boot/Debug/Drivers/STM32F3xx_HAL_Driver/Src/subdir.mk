################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal.c \
../Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_can.c \
../Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_cortex.c \
../Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_dma.c \
../Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_exti.c \
../Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_flash.c \
../Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_flash_ex.c \
../Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_gpio.c \
../Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_i2c.c \
../Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_i2c_ex.c \
../Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_pwr.c \
../Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_pwr_ex.c \
../Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_rcc.c \
../Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_rcc_ex.c \
../Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_dma.c \
../Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_exti.c \
../Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_gpio.c \
../Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_rcc.c \
../Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_usart.c \
../Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_utils.c 

OBJS += \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal.o \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_can.o \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_cortex.o \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_dma.o \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_exti.o \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_flash.o \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_flash_ex.o \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_gpio.o \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_i2c.o \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_i2c_ex.o \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_pwr.o \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_pwr_ex.o \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_rcc.o \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_rcc_ex.o \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_dma.o \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_exti.o \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_gpio.o \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_rcc.o \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_usart.o \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_utils.o 

C_DEPS += \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal.d \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_can.d \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_cortex.d \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_dma.d \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_exti.d \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_flash.d \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_flash_ex.d \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_gpio.d \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_i2c.d \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_i2c_ex.d \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_pwr.d \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_pwr_ex.d \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_rcc.d \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_rcc_ex.d \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_dma.d \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_exti.d \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_gpio.d \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_rcc.d \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_usart.d \
./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_utils.d 


# Each subdirectory must supply rules for building sources it contributes
Drivers/STM32F3xx_HAL_Driver/Src/%.o Drivers/STM32F3xx_HAL_Driver/Src/%.su Drivers/STM32F3xx_HAL_Driver/Src/%.cyclo: ../Drivers/STM32F3xx_HAL_Driver/Src/%.c Drivers/STM32F3xx_HAL_Driver/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_FULL_LL_DRIVER -DUSE_HAL_DRIVER -DSTM32F303xE -c -I../Core/Inc -I../Drivers/STM32F3xx_HAL_Driver/Inc -I../Drivers/STM32F3xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F3xx/Include -I../Drivers/CMSIS/Include -I"C:/Users/User/Documents/GitHub/STM32G0B1_Fabrica_Firmware/STM32F303_Bootloader/Fabrica_STM32F3RE_Boot/App" -I"C:/Users/User/Documents/GitHub/STM32G0B1_Fabrica_Firmware/STM32F303_Bootloader/Fabrica_STM32F3RE_Boot/../../ThirdParty/openblt/Target/Source" -I"C:/Users/User/Documents/GitHub/STM32G0B1_Fabrica_Firmware/STM32F303_Bootloader/Fabrica_STM32F3RE_Boot/../../ThirdParty/openblt/Target/Source/ARMCM4_STM32F3/GCC" -I"C:/Users/User/Documents/GitHub/STM32G0B1_Fabrica_Firmware/STM32F303_Bootloader/Fabrica_STM32F3RE_Boot/../../ThirdParty/openblt/Target/Source/ARMCM4_STM32F3" -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Drivers-2f-STM32F3xx_HAL_Driver-2f-Src

clean-Drivers-2f-STM32F3xx_HAL_Driver-2f-Src:
	-$(RM) ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal.cyclo ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal.d ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal.o ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal.su ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_can.cyclo ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_can.d ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_can.o ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_can.su ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_cortex.cyclo ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_cortex.d ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_cortex.o ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_cortex.su ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_dma.cyclo ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_dma.d ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_dma.o ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_dma.su ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_exti.cyclo ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_exti.d ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_exti.o ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_exti.su ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_flash.cyclo ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_flash.d ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_flash.o ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_flash.su ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_flash_ex.cyclo ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_flash_ex.d ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_flash_ex.o ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_flash_ex.su ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_gpio.cyclo ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_gpio.d ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_gpio.o ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_gpio.su ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_i2c.cyclo ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_i2c.d ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_i2c.o ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_i2c.su ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_i2c_ex.cyclo ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_i2c_ex.d ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_i2c_ex.o ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_i2c_ex.su ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_pwr.cyclo ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_pwr.d ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_pwr.o ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_pwr.su ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_pwr_ex.cyclo ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_pwr_ex.d ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_pwr_ex.o ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_pwr_ex.su ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_rcc.cyclo ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_rcc.d ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_rcc.o ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_rcc.su ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_rcc_ex.cyclo ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_rcc_ex.d ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_rcc_ex.o ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_hal_rcc_ex.su ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_dma.cyclo ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_dma.d ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_dma.o ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_dma.su ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_exti.cyclo ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_exti.d ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_exti.o ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_exti.su ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_gpio.cyclo ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_gpio.d ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_gpio.o ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_gpio.su ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_rcc.cyclo ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_rcc.d ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_rcc.o ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_rcc.su ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_usart.cyclo ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_usart.d ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_usart.o ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_usart.su ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_utils.cyclo ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_utils.d ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_utils.o ./Drivers/STM32F3xx_HAL_Driver/Src/stm32f3xx_ll_utils.su

.PHONY: clean-Drivers-2f-STM32F3xx_HAL_Driver-2f-Src

