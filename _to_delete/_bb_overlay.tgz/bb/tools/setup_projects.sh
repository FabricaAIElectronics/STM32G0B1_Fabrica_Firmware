#!/usr/bin/env bash
# Create the two ButtonBoard projects from the LEDDriver ones and overlay the
# board-specific sources. Run from the repository root.
set -euo pipefail

BOOT_SRC="STM32G0B1_Bootloader/G0B1_LEDDriver_Boot"
BOOT_DST="STM32G0B1_Bootloader/G0B1_ButtonBoard_Boot"
APP_SRC="STM32G0B1_Applciationprog/STM32G0_LEDDRIVER_PROG"
APP_DST="STM32G0B1_Applciationprog/STM32G0_BUTTONBOARD_PROG"
OVERLAY="${1:?usage: setup_projects.sh <overlay-dir>}"

[ -d "$BOOT_SRC" ] || { echo "missing $BOOT_SRC" >&2; exit 1; }
[ -d "$APP_SRC" ]  || { echo "missing $APP_SRC" >&2; exit 1; }

rm -rf "$BOOT_DST" "$APP_DST"

# Build artefacts and the LEDDriver's own bench files are not carried over.
rsync -a --exclude 'Debug/' --exclude 'Release/' --exclude '.metadata/' \
      "$BOOT_SRC/" "$BOOT_DST/"
rsync -a --exclude 'Debug/' --exclude 'Release/' --exclude '.metadata/' \
      --exclude 'LEDDriver.dbc' --exclude 'LEDPROGTest.*' \
      --exclude 'CLAUDE.md' \
      "$APP_SRC/" "$APP_DST/"

# Rename the per-project files that carry the old name.
mv "$BOOT_DST/G0B1_LEDDriver_Boot Debug.launch" \
   "$BOOT_DST/G0B1_ButtonBoard_Boot Debug.launch" 2>/dev/null || true
rm -f "$APP_DST/STM32G0_LEDDRIVER_PROG.ioc"

# LEDDriver-only modules: 3-channel PWM and the ADC voltage monitors. The
# button board has neither.
rm -f "$APP_DST/Core/Src/peripheral.c" "$APP_DST/Core/Inc/peripheral.h"

# Overlay the board-specific sources.
cp -f "$OVERLAY/app/Core/Inc/"*.h  "$APP_DST/Core/Inc/"
cp -f "$OVERLAY/app/Core/Src/"*.c  "$APP_DST/Core/Src/"
cp -f "$OVERLAY/app/ButtonBoard.dbc" "$APP_DST/"
cp -f "$OVERLAY/app/STM32G0_BUTTONBOARD_PROG.ioc" "$APP_DST/"

echo "--- created ---"
echo "$BOOT_DST"
echo "$APP_DST"
