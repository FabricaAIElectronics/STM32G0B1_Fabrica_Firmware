#!/usr/bin/env python3
"""Post-copy patches applied inside STM32G0B1_Fabrica_Firmware.

Run from the repository root. Every edit asserts that its anchor was found,
so a silent no-op is impossible: if the upstream file has moved on, this
fails loudly instead of producing a half-patched tree.
"""
import io
import os
import re
import sys

ROOT = os.getcwd()
errors = []


def read(p):
    with io.open(p, encoding="utf-8") as f:
        return f.read()


def write(p, s):
    with io.open(p, "w", encoding="utf-8", newline="\n") as f:
        f.write(s)


def sub_once(text, old, new, what):
    if old not in text:
        errors.append("anchor not found: %s" % what)
        return text
    return text.replace(old, new, 1)


# ---------------------------------------------------------------------------
# 1. Bootloader: point OpenBLT at the new address block.
# ---------------------------------------------------------------------------
blt = "STM32G0B1_Bootloader/G0B1_ButtonBoard_Boot/App/blt_conf.h"
t = read(blt)
t = sub_once(t, "#define BOOT_COM_CAN_TX_MSG_ID          (0x161)",
                "#define BOOT_COM_CAN_TX_MSG_ID          (0x781)",
             "blt_conf TX id")
t = sub_once(t, "#define BOOT_COM_CAN_RX_MSG_ID          (0x160)",
                "#define BOOT_COM_CAN_RX_MSG_ID          (0x780)",
             "blt_conf RX id")
write(blt, t)

# Eclipse project names, so both projects can sit in one workspace.
for proj, old, new in [
    ("STM32G0B1_Bootloader/G0B1_ButtonBoard_Boot/.project",
     "G0B1_LEDDriver_Boot", "G0B1_ButtonBoard_Boot"),
    ("STM32G0B1_Bootloader/G0B1_ButtonBoard_Boot/.cproject",
     "G0B1_LEDDriver_Boot", "G0B1_ButtonBoard_Boot"),
    ("STM32G0B1_Applciationprog/STM32G0_BUTTONBOARD_PROG/.project",
     "STM32G0_LEDDRIVER_PROG", "STM32G0_BUTTONBOARD_PROG"),
    ("STM32G0B1_Applciationprog/STM32G0_BUTTONBOARD_PROG/.cproject",
     "STM32G0_LEDDRIVER_PROG", "STM32G0_BUTTONBOARD_PROG"),
]:
    if os.path.exists(proj):
        s = read(proj)
        if old not in s:
            errors.append("project name not found in %s" % proj)
        write(proj, s.replace(old, new))
    else:
        errors.append("missing %s" % proj)

# ---------------------------------------------------------------------------
# 2. eeprom_driver.c — board-specific defaults.
# ---------------------------------------------------------------------------
ee = "STM32G0B1_Applciationprog/STM32G0_BUTTONBOARD_PROG/Core/Src/eeprom_driver.c"
t = read(ee)
new_default = """void LoadDefault(Config *config){
\t/* Dark and under the direct/J1 path. Coming up with the STM32 owning the
\t * LED nets would mean a board with no host on the bus sits there driving a
\t * pattern nobody asked for; coming up dark and passive is the state an
\t * operator can reason about. */
\tconfig->magic                = EEPROM_CFG_MAGIC;
\tconfig->default_led_mask     = 0x00;
\tconfig->default_led_int_mask = 0x00;
\tconfig->default_led_source   = 0;
\tconfig->flags                = 0x00;
\tconfig->reserved[0]          = 0;
\tconfig->reserved[1]          = 0;
}"""
m = re.search(r"void LoadDefault\(Config \*config\)\{.*?\n\}", t, re.S)
if not m:
    errors.append("LoadDefault not found in eeprom_driver.c")
else:
    t = t[:m.start()] + new_default + t[m.end():]
    write(ee, t)

# ---------------------------------------------------------------------------
# 3. Docs/CAN_Bus.md
# ---------------------------------------------------------------------------
doc = "Docs/CAN_Bus.md"
t = read(doc)

t = sub_once(
    t,
    "- **LEDDriver** (`STM32G0B1_Applciationprog/STM32G0_LEDDRIVER_PROG`)",
    "- **LEDDriver** (`STM32G0B1_Applciationprog/STM32G0_LEDDRIVER_PROG`)\n"
    "- **Button / Calibration Knob Board V5.5** "
    "(`STM32G0B1_Applciationprog/STM32G0_BUTTONBOARD_PROG`)",
    "module list")

t = sub_once(
    t,
    "This document describes the shared CAN bus that the three Fabrica "
    "STM32G0B1 modules use to coexist:",
    "This document describes the shared CAN bus that the Fabrica STM32G0B1 "
    "modules use to coexist:",
    "intro sentence")

t = sub_once(
    t,
    "0x780-0x7DF       │ Reserved (free)",
    "0x780-0x7BF       │ ButtonBoard          ← FABRICA\n"
    "0x7C0-0x7DF       │ Reserved (free)",
    "address map free range")

t = sub_once(
    t,
    "| **LEDDriver**  | `0x160` | `0x161` | `0x170-0x172` | `0x178-0x17A` |",
    "| **LEDDriver**  | `0x160` | `0x161` | `0x170-0x172` | `0x178-0x17A` |\n"
    "| **ButtonBoard** | `0x780` | `0x781` | `0x790-0x793` | `0x7A0-0x7A4` |",
    "device summary table")

t = sub_once(
    t,
    "| LEDDriver  | `STM32G0B1_Applciationprog/STM32G0_LEDDRIVER_PROG/LEDDriver.dbc` |",
    "| LEDDriver  | `STM32G0B1_Applciationprog/STM32G0_LEDDRIVER_PROG/LEDDriver.dbc` |\n"
    "| ButtonBoard | `STM32G0B1_Applciationprog/STM32G0_BUTTONBOARD_PROG/ButtonBoard.dbc` |",
    "per-device DBC table")

buttonboard_section = """
### ButtonBoard — `0x780-0x7A4`

fabricaAI calibration knob V5.5. Ten illuminated buttons, ten LED drives, one
PEC11L quadrature encoder with push-button, a 7-position ALPS SRBV170501
rotary and four SPDT toggles.

This block sits outside the CiA-301 gap the other three boards share, because
that gap (`0x101-0x17F`) is fully allocated. `0x780-0x7BF` is above CANopen's
NMT error-control range (`0x700-0x77F`) and below LSS (`0x7E4/0x7E5`), so it
collides with nothing.

| ID | Name | Dir | DLC | Cycle | Notes |
|---|---|---|---|---|---|
| `0x780` | Bootloader RX / Reset | RX | 2 | Event | byte[0]=0xFF triggers reset; bootloader then re-handles XCP CONNECT |
| `0x781` | Bootloader TX | TX | - | Event | OpenBLT XCP responses |
| `0x790` | CMD_LED | RX | 2 | Event | byte0 bits0-5 = LED_1..6, byte1 bits0-3 = LED_INT_1..4. Set bit = lit. Frames shorter than DLC=2 ignored |
| `0x791` | CMD_BUFFER | RX | 1 | Event | 0 = J1/direct path owns the LED nets, 1 = STM32 owns them. Firmware guarantees the two buffer banks are never both enabled |
| `0x792` | CMD_ENCODER | RX | 3 | Event | byte0 bit0 = apply; bytes 1-2 = new signed detent count (LE) |
| `0x793` | CMD_EEPROM | RX | 1 | Event | bit0 = save current LED pattern + source as power-on default, bit1 = reload built-in defaults |
| `0x7A0` | BCAST_KNOBSTATE | TX | 8 | 100 ms | enc pos (int16 LE, **detents**) + enc button + rotary pos + rotary raw one-hot + toggles + state/buff_sel nibbles + heartbeat |
| `0x7A1` | BCAST_BUTTONS | TX | 2 | 100 ms | byte0 bits0-5 = Button_3V3_1..6, byte1 bits0-3 = Button_3V3_int_1..4. Set bit = pressed |
| `0x7A2` | BCAST_LEDSTATE | TX | 3 | ~500 ms | LED pattern echo + which bank owns the nets. Phase 0 of the rotation |
| `0x7A3` | BCAST_DEVSTATUS | TX | 2 | ~500 ms | state + error mask. Phase 1 of the rotation |
| `0x7A4` | BCAST_EEPROMDATA | TX | 8 | ~500 ms | stored config echo. Phase 2 of the rotation |

Error mask bits (`BCAST_DEVSTATUS` byte 1): `0x01`=ROTARY_INVALID,
`0x02`=EEPROM (stored config rejected, defaults in use), `0x04`=CAN. Only the
CAN bit is fatal — a bad rotary contact or a missing EEPROM does not stop the
buttons and LEDs working, so those bits are advisory and self-clear.

`KNOBSTATE` byte 6 packs the state machine in the high nibble
(0=INIT 1=LOAD_CONFIG 2=RUNNING 3=ERROR) and the live output-enable levels in
the low nibble (bit0 = `BUFF_SEL_1` asserted, bit1 = `BUFF_SEL_2` asserted).
Reading back the pins rather than the requested source means that if the two
ever disagree, the host sees it.

`Encoder_Pos` counts **detents**, not quadrature edges. TIM2 runs x4 on
PA0/PA1 and the firmware divides by four, so a PEC11L gives one count per
click. `Rotary_Pos` is `0..6`, or `0xFF` when the switch lines do not describe
a valid position; `Rotary_Raw` carries the unprocessed one-hot pattern, which
is what to look at when diagnosing RS1. RS1 is make-before-break, so two
adjacent lines high is a normal mid-detent transition and the decoder holds
the previous position through it.

---
"""

t = sub_once(t, "\n---\n\n## 5. Bootloader workflow (per device)",
             "\n" + buttonboard_section + "\n## 5. Bootloader workflow (per device)",
             "insert ButtonBoard catalogue section")

t = sub_once(
    t,
    "The address pairs `(0x101/0x102)`, `(0x130/0x131)`, `(0x160/0x161)` are "
    "unique per device — three boards in bootloader at once will never collide "
    "with each other.",
    "The address pairs `(0x101/0x102)`, `(0x130/0x131)`, `(0x160/0x161)` and "
    "`(0x780/0x781)` are unique per device — four boards in bootloader at once "
    "will never collide with each other.",
    "bootloader pairs sentence")

t = sub_once(
    t,
    "- **Build all 6 projects** (3 bootloaders, 3 apps) in STM32CubeIDE — "
    "confirm no unresolved CAN ID symbols.",
    "- **Build all 8 projects** (4 bootloaders, 4 apps) in STM32CubeIDE — "
    "confirm no unresolved CAN ID symbols.",
    "verification checklist build line")

write(doc, t)

# ---------------------------------------------------------------------------
# 4. Docs/Fabrica_Bus.dbc — add the node and its messages.
# ---------------------------------------------------------------------------
bus = "Docs/Fabrica_Bus.dbc"
t = read(bus)
t = sub_once(t, "BU_: Host KincoDrive PowerStage LEDDriver",
                "BU_: Host KincoDrive PowerStage LEDDriver ButtonBoard",
             "BU_ node list")

src = read("STM32G0B1_Applciationprog/STM32G0_BUTTONBOARD_PROG/ButtonBoard.dbc")
blocks = []
for m in re.finditer(r"^BO_ (\d+) (\w+): (\d+) (\w+)\n((?: SG_ .*\n)*)",
                     src, re.M):
    msgid, name, dlc, node, sigs = m.groups()
    # Prefix in the combined file so message names cannot collide with the
    # other three boards' (BOOTLOADER_RX in particular).
    blocks.append("BO_ %s BTN_%s: %s %s\n%s" % (msgid, name, dlc, node, sigs))

if not blocks:
    errors.append("no BO_ blocks parsed from ButtonBoard.dbc")

# Append after the last existing message block, before any CM_/VAL_ trailer.
idx = t.find("\nCM_ ")
if idx == -1:
    idx = len(t)
t = t[:idx] + "\n" + "\n".join(blocks) + t[idx:]
write(bus, t)

if errors:
    sys.stderr.write("PATCH ERRORS:\n  " + "\n  ".join(errors) + "\n")
    sys.exit(1)
print("patch_repo.py: all anchors matched")
